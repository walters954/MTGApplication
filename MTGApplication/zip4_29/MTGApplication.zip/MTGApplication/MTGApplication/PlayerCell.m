//
//  PlayerCell.m
//  MTGApplication
//
//  Created by Vania Jarquin on 4/28/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import "PlayerCell.h"

@implementation PlayerCell

@end
