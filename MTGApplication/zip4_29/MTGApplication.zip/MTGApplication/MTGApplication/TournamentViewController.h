//
//  TournamentViewController.h
//  MTGApplication
//
//  Created by Vania Jarquin on 4/28/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TournamentViewController : UIViewController

@end
