//
//  PlayerDetailViewController.m
//  MTGApplication
//
//  Created by Pablo on 4/24/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import "PlayerDetailViewController.h"
#import "Player.h"
#import "PlayerStore.h"
#import "ImageStore.h"

@interface PlayerDetailViewController ()
<UINavigationControllerDelegate, UIImagePickerControllerDelegate,UITextFieldDelegate>

@end

@implementation PlayerDetailViewController
//Override the setter so that it sets the title as well as the player object 
-(void)setPlayer:(Player *)player{
    _player = player;
    self.navigationItem.title = _player.dci;
}
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    @throw [NSException exceptionWithName:@"Wrong initializer" reason:@"Use initForNewItem" userInfo:nil];
    return nil;
}
- (instancetype)initForNewPlayer:(BOOL)isNew{
    self = [super initWithNibName:nil bundle:nil];
    if(self){
        if(isNew){
            UIBarButtonItem *doneItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemDone target:self action:@selector(save:)];
            self.navigationItem.rightBarButtonItem = doneItem;
            UIBarButtonItem *cancelItem = [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemCancel target:self action:@selector(cancel:)];
            self.navigationItem.leftBarButtonItem = cancelItem;

        }
    }
    return self;
}
//When the view appears load the data into the nib
-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    Player* player = self.player;
    self.firstNameTextField.text = player.firstName;
    self.lastNameTextField.text = player.lastName;
    self.dciTextField.text = player.dci;
    self.pointsTextField.text = [player.points stringValue];
    
    //Allow View to get the imageKey
    NSString *imageKey = self.player.imageKey;
    
    //get the image for its key from image store
    UIImage *imageToDisplay = [[ImageStore sharedStore] imageForKey:imageKey];
    
    //use that image to put on the screen in image view
    self.profileImage.image = imageToDisplay;
    
}
//Here is where we do the saving. As the detail closes commit any changes
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self.view endEditing:YES];
    Player* player = self.player;
    player.firstName = self.firstNameTextField.text;
    player.lastName = self.lastNameTextField.text;
    player.dci = self.dciTextField.text;
    player.points = [NSNumber numberWithDouble:[self.pointsTextField.text doubleValue]];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (IBAction)save:(id)sender{
    [self.presentingViewController dismissViewControllerAnimated:YES completion:self.dismissBlock];
}
-(IBAction)cancel:(id)sender{
    [[PlayerStore sharedStore]removePlayer:self.player];
    [self.presentingViewController dismissViewControllerAnimated:YES completion:self.dismissBlock];
}
/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

//- (IBAction)clickSave:(id)sender {
//}

- (IBAction)takePicture:(id)sender {
    UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
    //If camera avaiable, take pic ELSE photo library
    if ([UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera]){
        imagePicker.sourceType = UIImagePickerControllerSourceTypeCamera;
    }
    else{
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    }
    imagePicker.delegate = self;
    
    //image picker on screen
    [self presentViewController:imagePicker animated:YES completion:NULL];
}

-(void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info{
    //get picked image from info dictionary
    UIImage *image = info[UIImagePickerControllerOriginalImage];
    
    //4/29 --
    [self.player setThumbnail:image];
        
    //store the image in ImageStore for this key
    [[ImageStore sharedStore]setImage:image forKey:self.player.imageKey];
    
    //put that image onto the screen in image view
    self.profileImage.image = image;
    
    //take image picker off screen with dismis methoe
    [self dismissViewControllerAnimated:YES completion:NULL];
}

//Keyboard 
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    
    return YES;
}
//Keyboard disappear, when tapping away from keyboard
- (IBAction)backgroundTapped:(id)sender {
    [self.view endEditing:YES];
}


@end
