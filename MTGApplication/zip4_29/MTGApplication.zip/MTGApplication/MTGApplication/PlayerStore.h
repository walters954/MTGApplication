//
//  PlayerStore.h
//  MTGApplication
//
//  Created by Pablo on 4/24/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Player;

@interface PlayerStore : NSObject
{
    NSMutableArray *allPlayers;
}
+ (instancetype) sharedStore;
- (NSArray *)allPlayers;
- (Player *)createPlayerwithFirst:(NSString*)first andLast:(NSString*)last withDCI:(NSString*)dci;
- (Player *)createPlayer;
- (void)removePlayer:(Player *)p;
- (void)movePlayerAtIndex:(int)from toIndex:(int)to;
- (NSString *)playerArchivePath;
- (BOOL)saveChanges;
@end
