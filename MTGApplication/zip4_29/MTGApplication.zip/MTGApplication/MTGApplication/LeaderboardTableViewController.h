//
//  LeaderboardTableViewController.h
//  MTGApplication
//
//  Created by Vania Jarquin on 4/27/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PlayerDetailViewController.h"
@interface LeaderboardTableViewController : UITableViewController

@end
