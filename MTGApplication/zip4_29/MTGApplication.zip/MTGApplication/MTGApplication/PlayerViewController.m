//
//  PlayerViewController.m
//  MTGApplication
//
//  Created by Pablo on 4/24/16.
//  Copyright © 2016 Team B. All rights reserved.
//

#import "PlayerViewController.h"
#import "Player.h"
#import "PlayerStore.h"
#import "PlayerCell.h"

@interface PlayerViewController ()
@property (nonatomic,strong) IBOutlet UIView* headerView;
@end

@implementation PlayerViewController

-(void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}
-(void)tableView:(UITableView*)tableView didSelectRowAtIndexPath:(nonnull NSIndexPath *)indexPath
{
    PlayerDetailViewController * detailViewController = [[PlayerDetailViewController alloc]initForNewPlayer:NO];
    NSArray* players = [[PlayerStore sharedStore] allPlayers];
    Player* selectedPlayer = players[indexPath.row];
    detailViewController.player = selectedPlayer;
    
    [self.navigationController pushViewController:detailViewController animated:YES];
}
- (UIView *)headerView {
    if(!_headerView){
        [[NSBundle mainBundle]loadNibNamed:@"HeaderView" owner:self options:nil];
        
    }
    return _headerView;
}

-(IBAction)addNewItem:(id)sender{
    Player* newPlayer = [[PlayerStore sharedStore] createPlayer];
    /*
    NSInteger lastRow = [[[PlayerStore sharedStore]allPlayers]indexOfObject:newPlayer];
    NSIndexPath * indexPath = [NSIndexPath indexPathForRow:lastRow inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];*/
    PlayerDetailViewController* detailViewController = [[PlayerDetailViewController alloc]initForNewPlayer:YES];
    detailViewController.player = newPlayer;
    detailViewController.dismissBlock = ^{
        [self.tableView reloadData];
    };
    UINavigationController *navController = [[UINavigationController alloc]initWithRootViewController:detailViewController];
    navController.modalPresentationStyle = UIModalPresentationFormSheet;
    [self presentViewController:navController animated:YES completion:nil];
}
/*
-(IBAction)toggleEditingMode:(id)sender{
    if(self.isEditing){
        [sender setTitle:@"Edit" forState:UIControlStateNormal];
        [self setEditing:NO animated:YES];
    }
    else{
        [sender setTitle:@"Done" forState:UIControlStateNormal];
        [self setEditing:YES animated:YES];
        
    }
    
}
 */
- (instancetype)init{
    self = [super initWithStyle:UITableViewStylePlain];
    if (self){
        UINavigationItem *navItem = self.navigationItem;
        navItem.title = @"Player List";
        UIBarButtonItem *bbi= [[UIBarButtonItem alloc]initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addNewItem:)];
        navItem.rightBarButtonItem = bbi;
        navItem.leftBarButtonItem = self.editButtonItem;
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Pablo" andLast:@"Valencia" withDCI:@"7869851235"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Isabella" andLast:@"Valencia" withDCI:@"7555551235"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Abel" andLast:@"Fernandez" withDCI:@"1234567890"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Candice" andLast:@"Garcia" withDCI:@"2589677412"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Issac" andLast:@"Martinez" withDCI:@"7536965268"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Bobby" andLast:@"Zavala" withDCI:@"6585236951"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Terry" andLast:@"Skye" withDCI:@"4585236951"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"William" andLast:@"Castillo" withDCI:@"9587536852"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Frank" andLast:@"Rodriguez" withDCI:@"3256214897"];
        [[PlayerStore sharedStore] createPlayerwithFirst:@"Yolanda" andLast:@"Johnson" withDCI:@"1012548498"];
        
    }
    
    return self;
}

- (instancetype)initWithStyle:(UITableViewStyle)style
{
    return [self init];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    //Commenting this line out to add custom cells
    //[self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:@"UITableViewCell"];
    
    //Load the custom cell xib
    UINib *nib = [UINib nibWithNibName:@"PlayerCell" bundle:nil];
    
    //Register nib, which contains the cell
    [self.tableView registerNib:nib forCellReuseIdentifier:@"PlayerCell"];
     
  //  UIView *header = self.headerView;
    //[self.tableView setTableHeaderView:header];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (instancetype)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil{
    self = [super initWithNibName:nibNameOrNil bundle: nibBundleOrNil];
    if(self){
        self.tabBarItem.title = @"Players";
    }
    return self;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return [[[PlayerStore sharedStore]allPlayers]count];
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(nonnull NSIndexPath *)indexPath{
    if(editingStyle == UITableViewCellEditingStyleDelete){
        NSArray* players = [[PlayerStore sharedStore]allPlayers];
        Player* player = players[indexPath.row];
        [[PlayerStore sharedStore]removePlayer:player];
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    }
}
- (UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    //Commenting out for custom cells
    //UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"UITableViewCell" forIndexPath:indexPath];
    //Get a new or recycled cell
    PlayerCell *cell = [tableView dequeueReusableCellWithIdentifier:@"PlayerCell" forIndexPath:indexPath];
    NSArray *players = [[PlayerStore sharedStore] allPlayers];
    Player *player = players[indexPath.row];
    //cell.textLabel.text = [player dci];
    //Configue the cell with the Player
    NSString *firstLast = player.firstName;
    firstLast = [firstLast stringByAppendingString:@" "];
    firstLast = [firstLast stringByAppendingString:player.lastName];
    cell.firstNameTextField.text = firstLast;
    cell.dciTextField.text = player.dci;
    //NSString *points = [NSNumber Player.points]; --hV
    cell.pointsTextField.text = [player.points stringValue];
    cell.profileImage.image = player.thumbnail;
    //cell.pointsTextField.text = @"0";
    return cell;
}

//4/29/16-----Making row height larger
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 80;
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
